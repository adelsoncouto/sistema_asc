package br.com.adelsoncouto.sgc.css;

import org.eclipse.jface.text.IDocument;

import br.com.adelsoncouto.sgc.util.Util;

public class Classe {

	private String[] linhas;
	private IDocument doc;

	public Classe(IDocument aDoc, String[] aLinhas) {
		this.doc = aDoc;
		this.linhas = aLinhas;
		if(this.linhas.length > 0){
			this.init();
		}
	}

	private void init() {
		String txt = "";
		txt += cabecalho();
		txt += inicioClasse();
		txt += atributo();
		txt += construtor();
		txt += destrutor();
		txt += get();
		txt += set();
		txt += sqlTabela();
		txt += sqlSelect();
		txt += sqlDelete();
		txt += sqlInsert();
		txt += sqlUpdate();
		txt += fimClasse();
		doc.set(txt);
	}

	private String fimClasse() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String sqlUpdate() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String sqlInsert() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String sqlDelete() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String sqlSelect() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String sqlTabela() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String set() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String get() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String destrutor() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String construtor() {
		// TODO Auto-generated method stub
		String txt = "";
		return txt;
	}

	private String atributo() {
		String txt = "";
		return txt;
	}

	private String inicioClasse() {
		String txt = "\n\nclasse "+
					Util.primeiraMaiuscula(Util.underlineToMaiuscula(this.linhas[0]))
					+"{";
		return txt;
	}

	private String cabecalho() {
		String txt = "<?php\n"
				+ "\nnamespace Model\\"
				+ "\ndate_default_timezone_set(\"America/Sao_Paulo\");"
				+ "\nif(strcmp(basename($_SERVER[\"SCRIPT_NAME\"]), basename(__FILE__)) === 0){ exit(\"Acesso negado\");}"
				+ "\n// ini_set(\"display_errors\",1);"
				+ "\n// ini_set(\"display_startup_erros\",1);"
				+ "\n// error_reporting(E_ALL);";
		return txt;
	}

	
	
}
