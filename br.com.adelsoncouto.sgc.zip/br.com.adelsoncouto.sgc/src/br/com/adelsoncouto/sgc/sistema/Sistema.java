package br.com.adelsoncouto.sgc.sistema;

public class Sistema {
	private String nome;
	
	public String getNome() {
		return this.nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}

}
