package br.com.adelsoncouto.sgc.util;

public class Util {

	
	public static String primeiraMinuscula(String aString){
		return aString.substring(0,1).toLowerCase()+aString.substring(1);
	}
	public static String primeiraMaiuscula(String aString){
		return aString.substring(0,1).toUpperCase()+aString.substring(1);
	}
	
	public static String maiusculaToUnderline(String aString){
		String s = "";
		for(char c:aString.toCharArray()){
			String l = String.valueOf(c).toUpperCase();
			if(s.length()>0 && l.equals(String.valueOf(c))){
				s += "_"+l.toLowerCase();
			}else{
				s += String.valueOf(c).toLowerCase();
			}
		}
		return s;
	}
	
	public static String underlineToMaiuscula(String aString){
		String s = "";
		boolean isMaiuscula = false;
		for(char c:aString.toCharArray()){
			String l = String.valueOf(c);
			if(l.equals("_")){
				isMaiuscula = true;
			}else if(isMaiuscula){
				isMaiuscula = false;
				s += l.toUpperCase();
			}else{
				s += String.valueOf(c);
			}
		}
		return s;
	}
	
	public static String maiusculaToEspaco(String aString){
		String s = "";
		for(char c:aString.toCharArray()){
			String l = String.valueOf(c).toUpperCase();
			if(s.length()>0){ 
				if(l.equals(String.valueOf(c))){
					s += " ";
				}
				s += c;
			}else{
				s += String.valueOf(c).toUpperCase();
			}
		}
		return s;
	}
	
	public static String espacoToMaiuscula(String aString){
		String s = "";
		boolean isMaiuscula = false;
		for(char c:aString.toCharArray()){
			String l = String.valueOf(c);
			if(l.equals(" ")){
				isMaiuscula = true;
			}else if(isMaiuscula){
				isMaiuscula = false;
				s += l.toUpperCase();
			}else{
				s += String.valueOf(c);
			}
		}
		return s;
	}
	
	
	public static void main(String[] args){
		String s = "adelson silva couto";
		System.out.println(Util.espacoToMaiuscula(s));
	}
}
